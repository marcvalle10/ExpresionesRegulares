import java.util.regex.*;

public class ER {
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Debe proporcionar una cadena como argumento.");
            return;
        }

        String input = args[0].toLowerCase(); // Convertir a minúsculas para uniformidad

        // Expresiones regulares
        String regexHolaMundo = "Hola mundo";
        String regexHolaMundoIgnoreCase = "(?i)hola mundo";
        String regexPalabras = "Java|Python|Go|Pascal|Perl";
        String regexCorreoUnison = "@[uU]?[nsNS][ioIO][snSN]\\.mx";
        String regexNombreArchivo = "ISI\\d{4}-[12]\\.(csv|txt)";

        // Validación usando Matcher y Pattern
        System.out.println("Expresión valida para 'Hola mundo': " + validarExpresion(input, regexHolaMundo));
        System.out.println("Expresión valida para 'Hola mundo' (ignorando mayúsculas/minúsculas): " +
                validarExpresion(input, regexHolaMundoIgnoreCase));
        System.out.println("Expresión valida para palabras de la lista: " + validarExpresion(input, regexPalabras));
        System.out.println("Expresión valida para correo de la Universidad de Sonora: " +
                validarExpresion(input, regexCorreoUnison));
        System.out.println("Expresión valida para nombre de archivo: " + validarExpresion(input, regexNombreArchivo));
    }

    // Método para validar expresiones regulares usando Matcher y Pattern
    private static String validarExpresion(String input, String regex) {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);

        if (matcher.matches()) {
            return "Válido";
        } else {
            return "No válido";
        }
    }
}