import java.util.Scanner;
import java.util.regex.*;

public class Er {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingresa una expresión regular:");
        String expresion = scanner.nextLine();

        System.out.println("Ingresa la cadena a validar:");
        String cadena = scanner.nextLine().toLowerCase(); // Convertir a minúsculas para uniformidad

        boolean esExpresionValida = validarExpresion(cadena, expresion);

        if (esExpresionValida) {
            System.out.println("La cadena cumple con la expresión regular.");
        } else {
            System.out.println("La cadena no cumple con la expresión regular.");
        }

        scanner.close();
    }

    // Método para validar expresiones regulares usando Matcher y Pattern
    private static boolean validarExpresion(String input, String regex) {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        return matcher.matches();
    }
}
